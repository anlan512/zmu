﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例4_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class Calculator
        {
            private int a;
            private int b;
            private int B
            {
                get { return b; }
                set
                {
                    if (value == 0) b = 1;
                    else b = value;
                }
            }
            public Calculator(int i, int j)
            {
                a = i; b = j;
            }
            public int add()
            {
                return a + b;
            }
            public int subtract()
            {
                return a - b;
            }
            public int multiply()
            {
                return a * b;
            }
            public int divide()
            {
                return a / B;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);
            Calculator x = new Calculator(a, b);
            lblShow.Text = "两数之和为" + x.add();

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);
            Calculator x = new Calculator(a, b);
            lblShow.Text = "两数之差为" + x.subtract();

        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);
            Calculator x = new Calculator(a, b);
            lblShow.Text = "两数之积为" + x.multiply();

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtA.Text);
            int b = int.Parse(txtB.Text);
            Calculator x = new Calculator(a, b);
            lblShow.Text = "两数之商为" + x.divide();

        }
      
    }
}
