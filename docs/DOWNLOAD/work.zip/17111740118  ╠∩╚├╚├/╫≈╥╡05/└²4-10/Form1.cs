﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例4_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Student a;
            if (txtAge.Text =="")
            {
                if(txtName.Text ==""){
                    lblShow.Text ="调用无参构造函数(默认构造函数):";
                    a = new Student();
                }
                else 
                {
                    lblShow.Text = "调用有两个参数的构造函数:";
                    a = new Student(txtName.Text);
                }
            }
            else 
            {
                int age = Convert.ToInt32 (txtAge.Text);
                    lblShow .Text = "调用有两个参数的构造函数:";
                    a = new Student(txtName.Text,age);
            }
            lblShow.Text +="\n" + a.getInfo();
        }
    }
    public class Student
    {
        private string name;
        private int age;
        public Student ():this("无名",20){}
        public Student (string name):this(name,20){}
        public Student (string name,int age)
        {
            this.name = name;
            this.age = age;
        }
        public string getInfo()
        {
            return string .Format("姓名:{0},年龄:{1}岁。",this.name,this.age);

        }
    }
}
