﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例5_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Animal
        {
            protected string name;
            protected int age;
            public Animal(string name, int age)
            {
                this.name = name;
                this.age = age;
            }
            public virtual string Eat()
            {
                return string.Format("动物{0}:我要吃东西!", name);
            }
        }
        public class Dog : Animal
        {
            private string type;
            public Dog(string name, int age, string type)
                : base(name, age)
            {
                this.type = type;
            }
            public string GetMessage()
            {
                return string.Format("狗狗({0}):{}", name, type, age);
            }
            public override string Eat()
            {
                return string.Format("狗狗({0}):我要吃骨头!", name);
            }
        }
        private void btnCtBase_Click(object sender, EventArgs e)
        {
            int age = Convert.ToInt32(txtAge.Text);
            Animal a = new Animal(txtName.Text, age);
            lblShow.Text = AnimalEat(a); 
        }
        private void btnCtChild_Click(object sender, EventArgs e)
        {
            int age = Convert.ToInt32(txtAge.Text);
            Dog d = new Dog(txtName.Text,age,txtType.Text);
            lblShow.Text = AnimalEat(d); 
        }
        private string AnimalEat(Animal x)
        {
            return x.Eat();
        }

    }
}
