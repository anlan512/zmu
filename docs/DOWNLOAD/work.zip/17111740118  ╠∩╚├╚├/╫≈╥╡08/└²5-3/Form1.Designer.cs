﻿namespace 例5_3
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCtBase = new System.Windows.Forms.Button();
            this.btnCtChild = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtType = new System.Windows.Forms.TextBox();
            this.lblShow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "姓名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(186, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "年龄：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(378, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "品种：";
            // 
            // btnCtBase
            // 
            this.btnCtBase.Location = new System.Drawing.Point(44, 205);
            this.btnCtBase.Name = "btnCtBase";
            this.btnCtBase.Size = new System.Drawing.Size(182, 36);
            this.btnCtBase.TabIndex = 3;
            this.btnCtBase.Text = "创建基类对象并调用方法";
            this.btnCtBase.UseVisualStyleBackColor = true;
            this.btnCtBase.Click += new System.EventHandler(this.btnCtBase_Click);
            // 
            // btnCtChild
            // 
            this.btnCtChild.Location = new System.Drawing.Point(293, 207);
            this.btnCtChild.Name = "btnCtChild";
            this.btnCtChild.Size = new System.Drawing.Size(189, 33);
            this.btnCtChild.TabIndex = 4;
            this.btnCtChild.Text = "创建子类对象并调用方法";
            this.btnCtChild.UseVisualStyleBackColor = true;
            this.btnCtChild.Click += new System.EventHandler(this.btnCtChild_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(65, 30);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(77, 21);
            this.txtName.TabIndex = 5;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(244, 29);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(92, 21);
            this.txtAge.TabIndex = 6;
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(437, 30);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(84, 21);
            this.txtType.TabIndex = 7;
            // 
            // lblShow
            // 
            this.lblShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShow.Location = new System.Drawing.Point(22, 80);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(459, 86);
            this.lblShow.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 262);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnCtChild);
            this.Controls.Add(this.btnCtBase);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCtBase;
        private System.Windows.Forms.Button btnCtChild;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label lblShow;
    }
}

