﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例4_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Student a;
            a = new Student();
            Student b = new Student();
            a.name = "令狐冲";
            a.age = 21;
            string strMsg = a.GetMessage();
            lblShow.Text = strMsg;
            b.name = "郭靖";
            b.age = 22;
            lblShow.Text += "\n" + b.GetMessage();
        }
    }
    class Student
    {
        public string name;
        public int age;
        public string GetMessage()
        {
            return string.Format("姓名:{0},年龄:{1}岁。", this.name, this.age);
        }
    }
 }
    

