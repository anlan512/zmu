﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例5_22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Animal
        {
            protected string name;
            protected int age;
            public Animal()
            {
                this.name = "未知";
                this.age = 0;
            }
            public Animal(string name, int age)
            {
                this.name = name;
                this.age = age;
            }
            public string Eat()
            {
                return string.Format("动物{0}:我要吃东西!", name);
            }
        }
        public class Dog : Animal
        {
            private string type;
            public Dog()
            {
                type = "未知";
            }
            public Dog(string name, int age, string type)
                : base(name, age)
            {
                this.type = type;
            }
            public string GetMessage()
            {
                return string.Format("狗狗({0}):我是{1},今年{2}岁了。", name, type, age);
            }
        }
        private void btnCreate_Click(object sender, EventArgs e)
        {
            Dog d;
            if (txtName.Text == "") d = new Dog();
            else
            {
                int age = Convert.ToInt32(txtAge.Text);
                d = new Dog(txtName.Text, age, txtType.Text);
            }
            lblShow.Text = d.GetMessage();
            lblShow.Text += "\n\n" + d.Eat();
            
        }
    }
}
