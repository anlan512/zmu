﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例6_2
{
    using System.Collections;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Hashtable a = new Hashtable();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int stuNO = Convert.ToInt32(txtStuNo.Text);
            Student stu = new Student(txtName.Text, stuNO);
            a.Add(stuNO, stu);
            lblShow.Text = "";
            display();
        }
        private void display()
        {
            foreach (object x in a.Values)
            {
                Student stu = (Student)x;
                lblShow.Text += "\n" + stu.ShowMsg();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int key = Convert.ToInt32(txtKey.Text);
            a.Remove(key);
            lblShow.Text = "";
            display();
        }
        public class Student
        {
            string name;
            int stuNo;
            public Student(string name, int no)
            {
                this.name = name;
                this.stuNo = no;
            }
            public string ShowMsg()
            {
                return string.Format("学号:{0},姓名：{1}!", stuNo, name);
            }
        }
    }
}
        
  
 
