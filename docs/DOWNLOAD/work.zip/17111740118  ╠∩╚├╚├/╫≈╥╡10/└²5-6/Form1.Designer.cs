﻿namespace 例5_6
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblShow = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtLx = new System.Windows.Forms.TextBox();
            this.txtLy = new System.Windows.Forms.TextBox();
            this.txtRx = new System.Windows.Forms.TextBox();
            this.txtRy = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "左上角(X):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "左上角(Y):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(194, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "右下角(X):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(193, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "右下角(Y):";
            // 
            // lblShow
            // 
            this.lblShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShow.Location = new System.Drawing.Point(23, 125);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(351, 73);
            this.lblShow.TabIndex = 4;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(256, 214);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(95, 37);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "计算面积";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtLx
            // 
            this.txtLx.Location = new System.Drawing.Point(66, 25);
            this.txtLx.Name = "txtLx";
            this.txtLx.Size = new System.Drawing.Size(66, 21);
            this.txtLx.TabIndex = 6;
            // 
            // txtLy
            // 
            this.txtLy.Location = new System.Drawing.Point(68, 70);
            this.txtLy.Name = "txtLy";
            this.txtLy.Size = new System.Drawing.Size(66, 21);
            this.txtLy.TabIndex = 7;
            // 
            // txtRx
            // 
            this.txtRx.Location = new System.Drawing.Point(261, 30);
            this.txtRx.Name = "txtRx";
            this.txtRx.Size = new System.Drawing.Size(89, 21);
            this.txtRx.TabIndex = 8;
            // 
            // txtRy
            // 
            this.txtRy.Location = new System.Drawing.Point(263, 68);
            this.txtRy.Name = "txtRy";
            this.txtRy.Size = new System.Drawing.Size(86, 21);
            this.txtRy.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 262);
            this.Controls.Add(this.txtRy);
            this.Controls.Add(this.txtRx);
            this.Controls.Add(this.txtLy);
            this.Controls.Add(this.txtLx);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblShow;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtLx;
        private System.Windows.Forms.TextBox txtLy;
        private System.Windows.Forms.TextBox txtRx;
        private System.Windows.Forms.TextBox txtRy;
    }
}

