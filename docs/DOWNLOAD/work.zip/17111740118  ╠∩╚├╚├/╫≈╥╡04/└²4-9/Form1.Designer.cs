﻿namespace 例4_9
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblShow = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.btnTwoInt = new System.Windows.Forms.Button();
            this.btnTwoDouble = new System.Windows.Forms.Button();
            this.btnThreeInt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "a=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "b=";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "c=";
            // 
            // lblShow
            // 
            this.lblShow.AutoSize = true;
            this.lblShow.Location = new System.Drawing.Point(37, 183);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(0, 12);
            this.lblShow.TabIndex = 3;
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(101, 18);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(99, 21);
            this.txtA.TabIndex = 4;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(102, 60);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(97, 21);
            this.txtB.TabIndex = 5;
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(103, 99);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(98, 21);
            this.txtC.TabIndex = 6;
            // 
            // btnTwoInt
            // 
            this.btnTwoInt.Location = new System.Drawing.Point(272, 15);
            this.btnTwoInt.Name = "btnTwoInt";
            this.btnTwoInt.Size = new System.Drawing.Size(199, 24);
            this.btnTwoInt.TabIndex = 7;
            this.btnTwoInt.Text = "两个整数的最大数";
            this.btnTwoInt.UseVisualStyleBackColor = true;
            this.btnTwoInt.Click += new System.EventHandler(this.btnTwoInt_Click);
            // 
            // btnTwoDouble
            // 
            this.btnTwoDouble.Location = new System.Drawing.Point(271, 53);
            this.btnTwoDouble.Name = "btnTwoDouble";
            this.btnTwoDouble.Size = new System.Drawing.Size(200, 22);
            this.btnTwoDouble.TabIndex = 8;
            this.btnTwoDouble.Text = "两个双精度数的最大数";
            this.btnTwoDouble.UseVisualStyleBackColor = true;
            this.btnTwoDouble.Click += new System.EventHandler(this.btnTwoDouble_Click);
            // 
            // btnThreeInt
            // 
            this.btnThreeInt.Location = new System.Drawing.Point(272, 96);
            this.btnThreeInt.Name = "btnThreeInt";
            this.btnThreeInt.Size = new System.Drawing.Size(198, 23);
            this.btnThreeInt.TabIndex = 9;
            this.btnThreeInt.Text = "三个整数的最大数";
            this.btnThreeInt.UseVisualStyleBackColor = true;
            this.btnThreeInt.Click += new System.EventHandler(this.btnThreeInt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 262);
            this.Controls.Add(this.btnThreeInt);
            this.Controls.Add(this.btnTwoDouble);
            this.Controls.Add(this.btnTwoInt);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblShow;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Button btnTwoInt;
        private System.Windows.Forms.Button btnTwoDouble;
        private System.Windows.Forms.Button btnThreeInt;
    }
}

