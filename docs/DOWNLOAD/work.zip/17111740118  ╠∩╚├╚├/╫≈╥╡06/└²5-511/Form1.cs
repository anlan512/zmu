﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例5_511
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Student
        {
            private static int males = 0;
            private static int females = 0;
            public static int number = 0;
            public string Name;
            public char Sex;
            public int Age;
            public Student(string name, char sex, int age)
            {
                Name = name; Sex = sex; Age = age;
                if (sex == '男') males++;
                if (sex == '女') males++;
            }
            public static int NumberOfMales()
            {
                return males;
            }
            public static int NumberOfFemales
            {
                get { return females; }
            }
        }
        Student[] ps = new Student[5];
        private void btnAdd_Click(object sender, EventArgs e)
        {
            char sex = char.Parse(txtSex.Text);
            int age = int.Parse(txtAge.Text);
            ps[Student.number] = new Student(txtName.Text, sex, age);
            Student.number++;
            lblShow.Text = string.Format("添加成功:{0}人", Student.number);
        }
        private void btnCount_Click(object sender, EventArgs e)
        {
            lblShow.Text += string.Format("\n男生人数:{}", Student.NumberOfMales());
            lblShow.Text += string.Format("\n女生人数:{}", Student.NumberOfFemales);
            lblShow.Text += string.Format("\n学生名单如以下:\n");
            foreach (Student p in ps)
            {
                if (p != null) lblShow.Text += string.Format("{0}", p.Name);
            }
        }
    }
}
