﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例5_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void display(Shape s)
        {
            lblShow.Text = "体积为:" + s.Cubage();
        }

        private void btnGlobe_Click(object sender, EventArgs e)
        {
            double r = Convert.ToDouble(txtRadius.Text);
            Globe g = new Globe(r);
            display(g);
        }

        private void btnCone_Click(object sender, EventArgs e)
        {
            double r = Convert.ToDouble(txtRadius.Text);
            double h = Convert.ToDouble(txtHigh.Text);
            Cone c = new Cone(r, h);
            display(c);

        }

        private void btnCylinder_Click(object sender, EventArgs e)
        {
            double r = Convert.ToDouble(txtRadius.Text);
            double h = Convert.ToDouble(txtHigh.Text);
            Cylinder c = new Cylinder(r, h);
            display(c);
        }
        public abstract class Shape
        {
            protected double radius;
            public Shape(double r)
            {
                radius = r;
            }
            public abstract double Cubage();
        }
        public class Globe : Shape
        {
            public Globe(double r) : base(r) { }
            public override double Cubage()
            {
                return 3.14 * radius * radius * radius * 4.0 / 3; ;
            }
        }
        public class Cone : Shape
        {
            private double high;
            public Cone(double r, double h)
                : base(r)
            {
                high = h;
            }
            public override double Cubage()
            {
                return 3.14 * radius * radius * high / 3;
            }
        }
        public class Cylinder : Shape
        {
            private double high;
            public Cylinder(double r, double h)
                : base(r)
            {
                high = h;
            }
            public override double Cubage()
            {
                return 3.14 * radius * radius * high;
            }
        }

    }
}
