﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例4_2非
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class Circle
        {
            const double pi = 3.1415926;
            public double r;
            public double Area()
            {
                return pi * r * r;
            }
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Circle c = new Circle();
            c.r = Convert.ToDouble(txtR.Text);
            lblShow.Text = string.Format("半径为{0}的圆的面积为:{1}", c.r, c.Area());
        }
    }
}
