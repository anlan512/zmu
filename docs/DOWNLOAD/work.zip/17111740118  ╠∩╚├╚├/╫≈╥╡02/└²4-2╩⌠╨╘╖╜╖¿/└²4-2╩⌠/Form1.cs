﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例4_2属
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Circle c = new Circle();
            c.R = Convert.ToDouble(txtR.Text);
            lblShow.Text = string.Format("半径为{0}的圆的面积为:{1}", c.R, c.Area);
        }
    }
    class Circle
    {
        const double pi = 3.1415926;
        private double r;
        public double R
        {
            get { return r; }
            set
            {
                if (value < 0) r = 0;
                else r = value;
            }
        }
        public double Area
        {
            get { return pi * R * R;}
        }
    }
}

