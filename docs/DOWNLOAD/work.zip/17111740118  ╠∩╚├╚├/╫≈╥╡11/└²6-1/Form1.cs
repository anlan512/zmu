﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 例6_1
{
    using System.Collections; 
    public partial class Form1 : Form
    {
        ArrayList a = new ArrayList ();
        private void display()
        {
            foreach (object x in a)
            {
                Student s = (Student)x;
                lblShow .Text +="\n" + s.ShowMsg();
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
        public class Student
        {
            string name;
            int stuNo;
            public Student(string name, int no)
            {
                this.name = name;
                this.stuNo = no;
            }
            public string ShowMsg()
            {
                return string.Format("学号:{0},姓名：{1}!", stuNo, name);
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int stuNo = Convert .ToInt32 (txtStuNo .Text);
            Student x = new Student (txtName .Text ,stuNo );
            a.Add (x);
            lblShow.Text ="";
            display();
        }
        private void btnInsert_Click(object sender, EventArgs e)
        {
            int stuNo = Convert .ToInt32 (txtStuNo .Text);
            int index = Convert .ToInt32 (txtIndex .Text);
            Student x = new Student(txtName.Text,stuNo);
            a.Insert(index, x);
            lblShow.Text ="";
            display();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = Convert .ToInt32 (txtIndex.Text);
            a.RemoveAt (index);
            lblShow.Text ="";
            display();
        }

        private void btnForeach_Click(object sender, EventArgs e)
        {
            lblShow .Text = "";
            display();
        }
    }
}
