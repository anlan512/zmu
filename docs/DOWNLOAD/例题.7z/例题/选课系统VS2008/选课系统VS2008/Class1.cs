﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 选课系统VS2008
{
    public static class Class1
    {
        public static Form1 _form1;
    }
}
