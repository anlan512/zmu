﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 选课系统VS2008
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str1 = "server=.\\sqlexpress;database=zmc;integrated security=true";
            SqlConnection con = new SqlConnection(str1);
            con.Open();
            string sql = "select * from student where sno='" + textBox2.Text + "'and sname='" + textBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                string b = textBox2.Text;
                Form2 form2 = new Form2(b);
                form2.Show();
            }
            else
            {
                MessageBox.Show("姓名或学号错误，请重新输入！", "登录失败！");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Class1._form1 = this;
        }
    }
}
