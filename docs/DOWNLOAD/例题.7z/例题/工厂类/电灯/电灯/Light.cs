﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 电灯
{
    public abstract class Light
    {
            public abstract void TurnOn();//开
            public abstract void TurnOff();//关
     }
     public class BulbLight : Light
     {
          public override void TurnOn()
            {
                Console.WriteLine("你打开的白炽灯！");
            }
            public override void TurnOff()
            {
                Console.WriteLine("你关闭的白炽灯！");
            }
        }
        public class TubeLight : Light
        {
            public override void TurnOn()
            {
                Console.WriteLine("你打开的日光灯！");
            }
            public override void TurnOff()
            {
                Console.WriteLine("你关闭的日光灯！");
            }
        }
  }
