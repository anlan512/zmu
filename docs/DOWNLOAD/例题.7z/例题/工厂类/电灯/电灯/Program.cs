﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 电灯
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Console.WriteLine("请输入灯的类型：（日光灯或白炽灯）");
            string light = Console.ReadLine();
            LSF LightType = new LSF();
            Light light1 = LightType.Creater(light);
            light1.TurnOn();
            light1.TurnOff();
            Console.ReadKey();
            
        }
    }
}
