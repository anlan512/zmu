﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 电灯
{
    class LSF
    {
        public Light Creater(string LightType)
        {
            if (LightType == "白炽灯")
                return new BulbLight();
            else if (LightType == "日光灯")
                return new TubeLight ();
            else
                return null;
        }
    }
}
