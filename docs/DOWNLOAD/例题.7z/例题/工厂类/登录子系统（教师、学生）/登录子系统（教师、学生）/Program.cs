﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 登录子系统_教师_学生_
{
    class Program
    {
        static void Main(string[] args)
        {
            simplefactory sf = new simplefactory();
            user u;
            u = sf.Createuser ("student","student");
            Console.WriteLine("...学生登录...");
            u = sf.Createuser ("teacher","teacher");
        }
    }
}
