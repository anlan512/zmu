﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 登录子系统_教师_学生_
{
    public class student : user
    {
        public student(string name, string type)
        {
            this.uname = name;
            this.utype = type;
        }
    }
}
