﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 从a到b整除
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("输入类型，起始值，终止值和整数");
            double  start = Convert.ToInt32(Console.ReadLine());
            double  end = Convert.ToInt32(Console.ReadLine());
            double  ste = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("sum累加，mul累乘，count总数");
            string ctype = Console.ReadLine();
            calcfactory cal = new calcfactory();
            calc c=cal.getcalc(ctype ,start ,end ,ste );
            double   res = 0;
            res = c.calcresult();
            Console.WriteLine("结果为："+res );
        }
    }
}
