﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 从a到b整除
{
    public class calcmul : calc
    {
        public calcmul(double  start, double end, double ste)
        {
            this.numstart = start ;
            this.numend = end ;
            this.step = ste ;
        }
        public override double  calcresult()
        {
            double result = 1.0;
            for (double  i = numstart; i <= numend; i++)
            {
                if (i % step == 0)
                   result=result *i  ;
            }
            return result ;
        }

    }
}