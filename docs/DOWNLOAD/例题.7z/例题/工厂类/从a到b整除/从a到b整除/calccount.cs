﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 从a到b整除
{
        public class calccount : calc
        {
            public calccount(double  start, double  end, double  ste)
            {
                this.numstart = start ;
                this.numend = end ;
                this.step = ste ;
            }
            public override double calcresult()
            {
                double result=0.0;
                for (double i = numstart; i <= numend; i++)
                {
                    if (i % step == 0)
                        result ++;
                }
                return result  ;
            }
        }
}