﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 从a到b整除
{
    class calcfactory
    {
        public calc getcalc(string ct, double  ss, double se, double  st)
        {
            {
                //case "a": calc c = new calccount(s, e, t); break;
                //case "b": calc c = new calcmul(s, e, t); break;
                //case "c": calc c = new calcsum(s, e, t); break;
                //default:c  = null;
                if (ct == "mul")
                    return new calcmul(ss, se, st);
                else if (ct == "count")
                    return new calccount(ss, se, st);
                else if (ct == "sum")
                    return new calcsum(ss, se, st);
                else null;
            }
        }
    }
}
