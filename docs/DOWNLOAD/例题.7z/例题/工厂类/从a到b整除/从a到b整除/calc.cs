﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 从a到b整除
{
    public abstract  class  calc
    {
        public int numstart;
        public int numend;
        public int step;
        public virtual float calcresult();
        //{
        //    float result = 0;
        //    return result;
        //}
        //public calc(int ns, int ne, int s)
        //{
        //    this.numstart = ns;
        //    this.numend = ne;
        //    this.step = s;
        //}
    }
}
