﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 灯_简单工厂_
{
    class lightfactory
    {
        public Light creat(string type)
        {
            if (type == "白炽灯")
                return new BulbLight();
            else if (type == "日光灯")
                return new TubeLight();
            else
                return null;
        }
    }
}
