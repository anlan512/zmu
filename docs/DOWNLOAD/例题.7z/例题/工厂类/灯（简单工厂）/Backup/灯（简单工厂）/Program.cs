﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 灯_简单工厂_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入灯的类型：（日光灯或白炽灯）");
            string light = Console.ReadLine();
            lightfactory  LightType = new lightfactory ();
            Light light1 = LightType.creat(light);
            light1.TurnOn();
            light1.TurnOff();
            Console.ReadKey();
        }
    }
}
