﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 登录form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            userfactory uf = new userfactory();
            string mynaem = textBox1.Text;
            string mytype = listBox1.Text;
            string mypwd = textBox2.Text;
            user me = uf.Createuser(mynaem, mytype, mypwd);
            label3.Text = me.list();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
