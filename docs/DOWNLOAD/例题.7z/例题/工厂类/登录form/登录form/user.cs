﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 登录form
{
   public  class user
    {
        public string uname;
        public string utype;
        public string list()
        {
            string u = "";
            u = "你的用户名是：" + uname + ",";
            u = u + "你所登录的是：" + utype + "子系统。";
            return u;
        }
    }
}
