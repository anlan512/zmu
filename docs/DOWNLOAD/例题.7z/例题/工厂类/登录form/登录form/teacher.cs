﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 登录form
{
   public  class teacher : user
    {
       public teacher(string name, string type)
       { 
            this.uname = name;
            this.utype = type;
       }
    }
}
