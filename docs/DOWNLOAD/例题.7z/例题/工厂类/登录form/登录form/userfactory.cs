﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 登录form
{
    class userfactory
    {
        public user Createuser(string name,string type,string pwd)
        {
            if (type == "学生" && pwd == "stud0001")
                return new student(name, type);
            else if (type == "教师" && pwd == "teach0001")
                return new teacher(name, type);
            else if (type == "管理员" && pwd == "ad0001")
                return new admin(name, type);
            else
                return null;
        }
    }
}
