﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace oledb连接数据库
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sv = textBox1.Text;
            string db = textBox2.Text;
            string scon = "server=" + sv + ";" + "database=" + db + ";" + "integrated security=true;Provider=SQLOLEDB";
            OleDbConnection c = new OleDbConnection(scon);
            try
            {
                c.Open();
                label3.Text = "连接成功！";
            }
            catch
            {
                label3.Text = "连接失败！";
            }
           c.Close();
        }
    }
}
