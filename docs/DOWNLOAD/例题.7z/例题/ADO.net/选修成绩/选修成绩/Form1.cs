﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 选修成绩
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection(@"server=(local)\sqlexpress;integrated security=true;database=zmc");
            cnn.Open();
            SqlCommand com = new SqlCommand("select cno,grade from sc where sno=@sno",cnn);
            com.Parameters.Add("@sno", SqlDbType.VarChar );
            com.Parameters[0].Value = textBox1.Text;
            SqlDataReader dr=com .ExecuteReader();
            while(dr.Read())
                  listBox1.Items.Add("课程号："+dr[1].ToString()+"成绩："+dr[2].ToString());
            dr.Close();
            cnn.Close();
        }
    }
}
