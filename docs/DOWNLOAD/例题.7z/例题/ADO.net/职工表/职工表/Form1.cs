﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 职工表
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable A = new DataTable();
            DataColumn B = new DataColumn();
            B = A.Columns.Add("职工编号", typeof(string));
            B = A.Columns.Add("职工姓名", typeof(string));
            DataRow dr1 = A.NewRow();
            dr1[0] = "1011";
            dr1[1] = "张三";
            DataRow dr2 = A.NewRow();
            dr2[0] = "1012";
            dr2[1] = "李四";
            A.Rows.Add(dr1);
            A.Rows.Add(dr2);
            dataGridView1.DataSource = A;
        }
    }
}
