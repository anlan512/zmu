﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 修改选课成绩
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
            SqlCommand cmd = new SqlCommand("update sc set grade=85 where sno='st2018101'", con);
            con.Open();
            label1 .Text ="影响了"+ cmd.ExecuteNonQuery().ToString() +"行";

            con.Close();
        }
    }
}
