﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
//using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生信息
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection cnn = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
        private void Form1_Load(object sender, EventArgs e)
        {
            cnn.Open();
            SqlCommand cmd = new SqlCommand("select distind sdept from stuent", cnn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                listBox2.Items.Add(dr[0].ToString() + "," + dr[1].ToString() + "," + dr[2].ToString() + "," + dr[3].ToString());
                dr.Close();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sno = Console.ReadLine();

            SqlCommand cmd = new SqlCommand("select sname,ssex,sage,sdept  from student where sno='" + sno + "'", cnn);
            cnn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
        }
    }
}
