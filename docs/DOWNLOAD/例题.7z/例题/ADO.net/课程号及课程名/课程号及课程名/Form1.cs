﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 课程号及课程名
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda .SelectCommand =new SqlCommand ("select* from course",conn );
            DataSet ds = new DataSet();
            sda.Fill(ds);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = new SqlCommand("select* from course", conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            string vcno = textBox1.Text;
            string vcn = textBox2.Text;
            DataRow dr = ds.Tables[0].NewRow();
            dr[0] = vcno;
            dr[1] = vcn;
            ds.Tables[0].Rows.Add(dr );
            sda.InsertCommand = new SqlCommand(string .Format (@"insert into course(cno,cname) values('{0}','{1}')",vcno,vcn ),conn );
            sda.Update(ds);
            conn.Close();
            sda.Dispose();
        }
    }
}
