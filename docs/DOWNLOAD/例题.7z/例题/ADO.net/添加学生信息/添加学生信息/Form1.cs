﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 添加学生信息
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             SqlConnection con = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
             con.Open();
             string insert = textBox1.Text.Trim();
             string[] val = insert.Split('，');
             string sql1 = string.Format(@"insert into student values('{0}','{1}','{2}''{3}',{4})", val[0], val[1], val[2], val[3], val[4]);
             SqlCommand cmd1 = new SqlCommand(sql1, con);
             cmd1.ExecuteNonQuery();
             SqlCommand cmd2 = new SqlCommand("select count(*) from student",con);
             textBox2.Text = cmd2.ExecuteNonQuery().ToString();
             MessageBox.Show("数据添加成功!");
        }
    }
}
