﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 科室表
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DataTable A = new DataTable();
            DataColumn B = new DataColumn();
            B = A.Columns.Add("编号", typeof(string));
            B = A.Columns.Add("姓名", typeof(string));
            B = A.Columns.Add("科室", typeof(string));
            DataRow dr = A.NewRow();
            dr[0] = "123455";
            dr[1] = "msyang";
            dr[2] = "1vx";
            A.Rows.Add(dr);
            dataGridView1.DataSource = A;
        }
    }
}
