﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace 控制台连接数据库
{
    class Program
    {
        static void Main(string[] args)
        {
              SqlConnection con=new SqlConnection ();
              con .ConnectionString=@"server=(local)\sqlexpress;Integrated Security=true;Database=zmc";
              {
                  try
                  {
                      con.Open();
                      Console.WriteLine("成功连接到zmc数据库！");
                  }
                  catch
                  {
                      Console.WriteLine("未连接到zmc数据库！");
                  }
              }
            Console .ReadLine ();
        }
    }
}
