﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace datatable读取表
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = "server=(Local)\\sqlexpress;database=zmc;integrated security=true";
            SqlConnection cn = new SqlConnection(s);
            cn.Open();
            string sql = "select top 3sno,sname from student";
            SqlDataAdapter sda = new SqlDataAdapter(sql, cn);//将对cn的select查询结果放到SqlDataAdapter sda对象中//
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            sda.Fill(ds);//将所查询的数据填充到dt//
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;//将所查询的数据显示到dataGridView1//
            /*最后4条语句可写成  
            sda.Fill(dt);
            dataGridView1.DataSource = dt;*/
        }
    }
}
