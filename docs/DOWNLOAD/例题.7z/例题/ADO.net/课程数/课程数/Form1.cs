﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 课程数
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
            string sql = "select count(*) from course where cname like '%'"+ textBox1 .Text +"'%'";//拼接字符串
            //string sql =string.Format(@ "select count(*) from course where cname like '%{0}%'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            label1.Text = "共有" + cmd.ExecuteScalar().ToString() + "门课程!";//返回单一值。

            con.Close();
        }
    }
}
