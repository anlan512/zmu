﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SQL连接数据库
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string srv = textBox1.Text;
            string db = textBox2.Text;
            listBox1.Items.Clear();
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "server="+srv +";database="+db +";integrated security=true";
            conn.Open();
            if (conn.State == ConnectionState.Open)
            {
                listBox1.Items.Add("数据库已连接！");
                listBox1.Items.Add("服务器名："+conn .DataSource );
                listBox1.Items.Add("数据库名：" + conn.DataSource);
                listBox1.Items.Add("服务器实例版本：" + conn.ServerVersion );
            }
            conn.Close();
            conn.Dispose();
        }
    }
}
