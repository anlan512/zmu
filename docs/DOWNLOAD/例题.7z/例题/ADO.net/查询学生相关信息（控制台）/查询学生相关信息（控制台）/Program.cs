﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace 查询学生相关信息_控制台_
{
    class Program
    {
        static void Main(string[] args)
        {
            string sno = Console.ReadLine();
            SqlConnection cnn = new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
            SqlCommand cmd = new SqlCommand("select sname,ssex,sage,sdept  from student where sno='"+sno +"'" , cnn);
            cnn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                Console.WriteLine("你的名字：{0}", sdr[0].ToString());
                Console.WriteLine("你的性别：{0}", sdr[1].ToString());
                Console.WriteLine("你的年龄：{0}", sdr[2].ToString());
                Console.WriteLine("你的系别：{0}", sdr[3].ToString());
            }
            Console.Read();
        }
    }
}
