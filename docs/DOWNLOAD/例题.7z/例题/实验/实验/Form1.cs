﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 实验
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=.\\sqlexpress;database=zmc;integrated security=true");
            con.Open();
            string str2 = "select * from student where sno='" + textBox1.Text + "'or sname='" + textBox2.Text + "'or ssex='" + textBox5.Text + "'or sage='" + textBox3.Text + "'or sdept='" + textBox4.Text + "'";
            SqlCommand cmd = new SqlCommand(str2,con);
            SqlDataReader sdr = cmd.ExecuteReader();
            BindingSource bs=new BindingSource();
            bs.DataSource=sdr;
            dataGridView1.DataSource = bs;
            sdr.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=.\\sqlexpress;database=zmc;integrated security=true");
            con.Open();
            string str2 = "select * from student";
            SqlCommand cmd = new SqlCommand(str2, con);
            SqlDataReader sdr = cmd.ExecuteReader();
            BindingSource bs = new BindingSource();
            bs.DataSource = sdr;
            dataGridView1.DataSource = bs;
            sdr.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString(); 
            textBox5.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString(); 
            textBox3.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString(); 
            textBox4.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

        }
    }
}
