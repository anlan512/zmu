﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生基本信息查询程序
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con=new SqlConnection(@"server=(local)\sqlexpress;database=zmc;integrated security=true");
        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            string sql1="select * from student";
            SqlDataAdapter sda=new SqlDataAdapter(sql1,con);
            DataTable dt=new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource=dt;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql2 = string.Format("select * from student where sno like '%{0}%'or sname like '%{0}%'or ssex like '%{0}%'or sage like '%{0}%'or sdept like '%{0}%'",textBox1.Text);
            SqlDataAdapter sda = new SqlDataAdapter(sql2,con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox2.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString(); textBox4.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString(); textBox5.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString(); textBox6.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql3 = string.Format(@"insert into student values('{0}','{1}','{2}','{3}','{4}')",textBox2.Text,textBox3.Text,textBox4.Text,textBox5.Text,textBox6.Text);
            SqlCommand cmd = new SqlCommand(sql3,con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            con.Open();
            string sql4 =string .Format ( "update student set sname='{1}',ssex='{2}',sage='{3}',sdept='{4}' where student.sno='{0}'",textBox2 .Text ,textBox3 .Text ,textBox4 .Text ,textBox5 .Text ,textBox6 .Text );
            SqlCommand com = new SqlCommand(sql4 ,con );
            com.ExecuteNonQuery();
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql5= string.Format(@"delete from student where student.sno='{0}'", textBox2.Text);
            SqlCommand cmd = new SqlCommand(sql5, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql6 = "select * from student";
            SqlDataAdapter sda = new SqlDataAdapter(sql6,con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
