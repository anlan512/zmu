﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 工作经历
{
    class Program
    {
        static void Display(string name, string sex, string age, string tiemArea, string company)
        {
            Console.WriteLine("{0}{1}{2}",name,sex ,age );
            Console.WriteLine("工作经历：{0}{1}", tiemArea, company);
        }
        static void Main(string[] args)
        {
            Display("郭靖","男","29","1998—2000","襄阳城守");
            Display("黄蓉", "女", "25", "1998—2000", "桃花岛");
            Display("韦小宝", "男", "18", "1998—2000", "紫禁城");
            Console.Read();
        }
    }
}
