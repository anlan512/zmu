﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 集abcde于一体
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = textBox1.Text;
            pass = textBox2.Text.Substring(0,3);
            if (radioButton1.Checked == true)
                if (pass == "stu")
                    label4.Text = "验证成功，欢迎" + user + "同学使用系统";
                else
                    label4.Text = "验证不成功，请重新输入";
            if (radioButton2.Checked == true)
                if (pass == "tea")
                    label4.Text = "验证成功，欢迎" + user + "老师使用系统";
                else
                    label4.Text = "验证不成功，请重新输入";
            if (radioButton3.Checked == true)
                if (pass == "adm")
                    label4.Text = "验证成功，欢迎" + user + "管理员使用系统";
                else
                    label4.Text = "验证不成功，请重新输入";
        }
    }
}
