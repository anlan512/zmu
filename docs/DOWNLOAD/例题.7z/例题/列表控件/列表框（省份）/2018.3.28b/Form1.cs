﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _2018._3._28b
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string[] city1 = { "成都", "九寨沟", "都江堰" };
            string[] city2 = { "贵阳", "毕节", "遵义" };
            string[] city3 = { "昆明", "大理", "丽江" };
            switch (comboBox1.SelectedIndex)
            {
                case 0: listBox1.Items.AddRange(city1); break;
                case 1: listBox1.Items.AddRange(city2); break;
                case 2: listBox1.Items.AddRange(city3); break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            //comboBox1.Items.Add("四川");
            //comboBox1.Items.Add("贵州");
            //comboBox1.Items.Add("云南");
            string[] pinc = { "四川", "贵州", "云南" };
            comboBox1.Items.AddRange(pinc);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           //此行不需
        }
    }
}
