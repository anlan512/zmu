﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace c
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select*  from student";
            if (radioButton1.Checked == true)//只要涉及单选按钮必有if (radioButton1.Checked == true)
                sql = sql + "where sdept='信息'";
            if (radioButton2.Checked)
                sql = sql + "where sdept='数学'";
            MessageBox.Show("SQL查询语句为："+sql );
        }
    }
}
