﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 组合框的使用
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string[] city1 = { "成都", "攀枝花", "都江堰" };
            string[] city2 = { "遵义", "贵阳", "麻江" };
            string[] city3 = { "大理", "丽江", "洱海" };
            string[] city4 = { "云阳", "涪陵", "万州" };
            switch (comboBox1.SelectedIndex)
            {
                case 0: listBox1.Items.AddRange(city1); break;
                case 1: listBox1.Items.AddRange(city2); break;
                case 2: listBox1.Items.AddRange(city3); break;
                case 3: listBox1.Items.AddRange(city4); break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] a = { "四川", "贵州", "云南", "重庆" }; //声明一个项目数组
            comboBox1.Items.AddRange(a);  //AddRange表示添加数组
        }
    }
}
