﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 列表框项目添加
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox2.Items.Add(listBox1.Text);// 他的Text项即鼠标选中项
            listBox1.Items.Remove(listBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i;
            for (i = 0; i < listBox1.Items.Count; i++)
                listBox2.Items.Add(listBox1.Items[i]);
            listBox1.Items.Clear();
                   
        }
    }
}
