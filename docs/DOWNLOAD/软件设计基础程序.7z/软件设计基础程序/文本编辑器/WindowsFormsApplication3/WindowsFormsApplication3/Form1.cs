﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.SelectedText;//将文本框1选取的内容赋给文本框2；
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.SelectedText;
            textBox1.SelectedText = "";   //删除文本框1中所选内容；
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.SelectedText = textBox2.Text;//将文本框1中所选内容替换成文本框2中的内容；
        }
    }
}
