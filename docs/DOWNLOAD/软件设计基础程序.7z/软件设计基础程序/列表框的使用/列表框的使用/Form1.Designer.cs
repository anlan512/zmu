﻿namespace 列表框的使用
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button添加 = new System.Windows.Forms.Button();
            this.button删除 = new System.Windows.Forms.Button();
            this.button清空 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(12, 35);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 184);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button添加
            // 
            this.button添加.Location = new System.Drawing.Point(169, 76);
            this.button添加.Name = "button添加";
            this.button添加.Size = new System.Drawing.Size(75, 23);
            this.button添加.TabIndex = 1;
            this.button添加.Text = "添加";
            this.button添加.UseVisualStyleBackColor = true;
            this.button添加.Click += new System.EventHandler(this.button1_Click);
            // 
            // button删除
            // 
            this.button删除.Location = new System.Drawing.Point(169, 136);
            this.button删除.Name = "button删除";
            this.button删除.Size = new System.Drawing.Size(75, 23);
            this.button删除.TabIndex = 2;
            this.button删除.Text = "删除";
            this.button删除.UseVisualStyleBackColor = true;
            this.button删除.Click += new System.EventHandler(this.button2_Click);
            // 
            // button清空
            // 
            this.button清空.Location = new System.Drawing.Point(169, 196);
            this.button清空.Name = "button清空";
            this.button清空.Size = new System.Drawing.Size(75, 23);
            this.button清空.TabIndex = 3;
            this.button清空.Text = "清空";
            this.button清空.UseVisualStyleBackColor = true;
            this.button清空.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(156, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button清空);
            this.Controls.Add(this.button删除);
            this.Controls.Add(this.button添加);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button添加;
        private System.Windows.Forms.Button button删除;
        private System.Windows.Forms.Button button清空;
        private System.Windows.Forms.TextBox textBox1;
    }
}

