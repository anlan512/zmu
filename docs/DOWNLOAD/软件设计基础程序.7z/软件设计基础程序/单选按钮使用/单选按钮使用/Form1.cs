﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 单选按钮使用
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.Red;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.Blue;

        }

        private void label3_Click(object sender, EventArgs e)
        {
            textBox1.Font = new Font("楷体", textBox1.Font.Size);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Font = new Font("黑体", textBox1.Font.Size);
        }
    }
}
