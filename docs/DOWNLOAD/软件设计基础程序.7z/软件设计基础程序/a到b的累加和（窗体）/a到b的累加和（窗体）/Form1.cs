﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace a到b的累加和_窗体_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float a,b,p,i;
            p=0;
            a = Convert.ToSingle(txtA.Text);
            b = Convert.ToSingle(txtB.Text);
            for (i=a; i <= b; i++)
                p = p + i;
            txtP.Text = Convert.ToString(p);
        }
    }
}
