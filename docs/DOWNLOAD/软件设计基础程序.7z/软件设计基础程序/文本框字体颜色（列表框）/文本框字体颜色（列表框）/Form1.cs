﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 文本框字体颜色_列表框_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Font = new Font(listBox1.Text, textBox1.Font.Size);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
                textBox1.BackColor = Color.Red;
            else
                textBox1.BackColor = Color.Yellow;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
