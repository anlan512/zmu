﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 输入与输出_任意两数之积_
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y, z;
            Console.WriteLine("请输入任意两个数");
            x = Convert.ToSingle(Console.ReadLine()); //用于转换（）的值赋给x
            y = Convert.ToSingle(Console.ReadLine());
            z = x * y;
            Console.WriteLine("两数之积为：{0}", z);
        }
    }
}
