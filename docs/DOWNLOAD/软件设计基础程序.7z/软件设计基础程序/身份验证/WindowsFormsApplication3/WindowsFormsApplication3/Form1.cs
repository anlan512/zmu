﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            if (radioButton1.Checked == true)
                if (textBox2.Text.Substring(0, 3) == "stu")//Substring(star,length)表示从第几位开始读取后面的几位；
                    labelShow.Text = "验证成功，" + "欢迎" + textBox1.Text + "同学";
                else
                    labelShow.Text = "验证失败";
            if(radioButton2.Checked==true)
                if(textBox2.Text.Substring(0,3)=="tea")
                    labelShow.Text = "验证成功，" + "欢迎" + textBox1.Text + "老师";
                else
                    labelShow.Text = "验证失败";
            if (radioButton3.Checked == true)
                if (textBox2.Text.Substring(0, 2) == "ad")
                    labelShow.Text = "验证成功，" + "欢迎" + textBox1.Text + "管理员";
                else
                    labelShow.Text = "验证失败";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
