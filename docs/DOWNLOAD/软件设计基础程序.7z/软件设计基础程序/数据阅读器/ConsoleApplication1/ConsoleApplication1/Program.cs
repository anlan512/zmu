﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace ConsoleApplication1
{
    class Program// 数据阅读器
    {
        static void Main(string[] args)
        {
            string s = @"server=.\sqlexpress;database=zmc;integrated security=true";
            SqlConnection cn = new SqlConnection(s);//建立连接对象
            cn.Open();
            Console.WriteLine("输入学号");
            string a = Console.ReadLine();
            string sql = "select avg(grade) from sc where sno='" + s + "'";
            SqlCommand c = new SqlCommand(sql, cn);
            SqlDataReader dr = c.ExecuteReader();
            if (dr.Read())
                Console.WriteLine("平均成绩是:{0}", dr[0].ToString());
            Console.ReadLine();
        }
    }
}
