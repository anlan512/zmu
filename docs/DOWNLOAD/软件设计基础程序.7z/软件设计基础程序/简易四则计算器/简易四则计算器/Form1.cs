﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 简易四则计算器
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn加_Click(object sender, EventArgs e)
        {
            float a, b,c;
            a = Convert.ToSingle(textBox1.Text);
            b = Convert.ToSingle(textBox2.Text);
            c = a + b;
            textBox3.Text = Convert.ToString(c);
        }

        private void button减_Click(object sender, EventArgs e)
        {
            float a, b, c;
            a = Convert.ToSingle(textBox1.Text);
            b = Convert.ToSingle(textBox2.Text);
            c = a - b;
            textBox3.Text = Convert.ToString(c);
        }

        private void button乘_Click(object sender, EventArgs e)
        {
            float a, b, c;
            a = Convert.ToSingle(textBox1.Text);
            b = Convert.ToSingle(textBox2.Text);
            c = a * b;
            textBox3.Text = Convert.ToString(c);
        }

        private void button除_Click(object sender, EventArgs e)
        {
            float a, b, c;
            a = Convert.ToSingle(textBox1.Text);
            b = Convert.ToSingle(textBox2.Text);
            c = a / b;
            textBox3.Text = Convert.ToString(c);
        }
    }
}
