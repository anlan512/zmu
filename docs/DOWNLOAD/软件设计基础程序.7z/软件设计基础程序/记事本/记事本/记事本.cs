﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 记事本
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 新建NToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Modified == true)//Modified，修改
            {
                DialogResult n = MessageBox.Show("文件" + Text + "”内容已修改\n是否要保存", "提示", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);//带有黄色感叹号的MessageBox
                switch (n)//使switch用语句判断
                {
                    case (DialogResult.Yes):
                        保存SToolStripMenuItem_Click(sender, e);//调用保存函数
                        break;
                    case (DialogResult.No):
                        richTextBox1.Text = "";
                        break;
                    case (DialogResult.Cancel):
                        richTextBox1.Modified = false;
                        break;
                }
            }  
        }

        private void 保存SToolStripMenuItem_Click(object sender, EventArgs e)
        {
             if (this.Filename ==string.Empty) //判断文件是否存在
            {
     //不存在就打开对话框保存,把用户单击对话框按钮时返回的值赋给枚举类的DialogResult变量result。DialogResult result = saveFileDialog1.ShowDialog();如果result值为DialogResult.Cancel,说明用户单击了取消按钮,则什么也不处理.
                if (result == DialogResult.Cancel)
                {
                    textBox1.Text = textBox1.Text;
                }
                else
                {
                    StreamWriter writer = new StreamWriter(saveFileDialog1.FileName, true, ASCIIEncoding.Default);
                    writer.Write(textBox1.Text);
                    writer.Close();
                    textBox1.Modified = false;
                }
            }
            else
            {
                StreamWriter writer = new StreamWriter(this.Filename, true, ASCIIEncoding.Default);
                writer.Write(textBox1.Text);
                writer.Close();
                textBox1.Modified = false;
            }
        }

        private void 另存为AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(saveFileDialog1.FileName, true, System.Text.Encoding.Default);
                writer.Write(textBox1.Text);
                writer.Close();
                textBox1.Modified = false;
            }
        }//另存为直接打开保存对话框,创建流写入对象(其构造函数参数一是保存路径及文件名,二是是否覆盖原文件,三是一本系统默认的字符编码保存),用流写入对象的write方法(要被写入保存的文本),最后关闭流写入对象。将文本的是否变动设为false,这样再关闭或保存时不会提示要求保存了。

        private void 页面设置UToolStripMenuItem_Click(object sender, EventArgs e)
        {
             printDialog1.Document = printDocument1;
             printDialog1.ShowDialog();
        }

        private void 打印PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.Document = printDocument1;
            if (printDialog1.ShowDialog(this) == DialogResult.OK)
                printDocument1.Print();
        }

        private void 退出XToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           
        }

        private void 撤销UToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }
        private void 剪切TToolStripMenuItem1_Click(object sender, EventArgs e)
        {
             richTextBox1.Cut();
        }
       
        private void 复制CToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void 粘贴PToolStripMenuItem_Click(object sender, EventArgs e)
        {
             richTextBox1.Paste();
        }

        private void 全选AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void 查找FToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 替换RToolStripMenuItem_Click(object sender, EventArgs e)
        {
             
        }

        private void 自动换行WToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.WordWrap = true;
        }

        private void 字体FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Font = fontDialog1.Font;
            }
        }

        private void 状态栏SToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void 关于记事本AToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 时间日期DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + DateTime.Now.ToString();
        }

        private void 打开OToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.Text = openFileDialog1.SafeFileName + "-记事本";                  //safeFileName为文件名不加路径
                StreamReader reader = new StreamReader(openFileDialog1.FileName, System.Text.Encoding.Default);
                textBox1.Text = reader.ReadToEnd();
                this.Filename = openFileDialog1.FileName;  //给公共字符串字段赋值用于保存时判断文件名是否存在
                reader.Close();
            }//打开创建的流读取对象,与流写入对象差不多。其中Filename是在类下面声明的值为""的字符串公共变量,在打开文本时就被文件路径及名称赋值，用于在以后保存文件时自动保存,而不是打开保存对话框保存
        }

        
    }
}
