﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 记事本
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 新建NToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Modified == true)
            {
                DialogResult n = MessageBox.Show("文件" + Text + "”内容已修改\n是否要保存", "提示", MessageBoxButtons.YesNoCancel);
                switch (n)
                {
                    case (DialogResult.Yes):
                        保存SToolStripMenuItem_Click(sender, e);
                        break;
                    case (DialogResult.No):
                        richTextBox1.Text = "";
                        break;
                    case (DialogResult.Cancel):
                        richTextBox1.Modified = false;
                        break;
                }
            }  
        }

        private void 保存SToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 另存为AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                System.IO.File.WriteAllText(saveFileDialog1.FileName,richTextBox1.Text);
        }

        private void 页面设置UToolStripMenuItem_Click(object sender, EventArgs e)
        {
             printDialog1.Document = printDocument1;
             printDialog1.ShowDialog();
        }

        private void 打印PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.Document = printDocument1;
            if (printDialog1.ShowDialog(this) == DialogResult.OK)
                printDocument1.Print();
        }

        private void 退出XToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 撤销UToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }
        private void 剪切TToolStripMenuItem1_Click(object sender, EventArgs e)
        {
             richTextBox1.Cut();
        }
       
        private void 复制CToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void 粘贴PToolStripMenuItem_Click(object sender, EventArgs e)
        {
             richTextBox1.Paste();
        }

        private void 全选AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void 自动换行WToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.WordWrap = true;
        }

        private void 字体FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            richTextBox1.Font = fontDialog1.Font;
        }

        private void 状态栏SToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void 关于记事本AToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 时间日期DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + DateTime.Now.ToString();
        }

        private void 打开OToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 编辑EToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 删除LToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectedText = "";
        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }

        
    }
}
