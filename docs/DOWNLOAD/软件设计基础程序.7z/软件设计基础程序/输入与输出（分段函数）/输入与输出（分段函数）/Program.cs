﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 输入与输出_分段函数_
{
    class Program
    {
        static void Main(string[] args)
        {
            float x, y;
            Console.WriteLine("请输入x的值");
            x = Convert.ToSingle(Console.ReadLine());    //用于转换（）的值赋给x
            if (x > 0)
                y = x + 10;
            else if (x == 0)
                y = 10;
            else
                y = x * 5;
            Console.WriteLine("分段函数y的值：{0}", y);
        }
    }
}
