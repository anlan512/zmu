﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float n, m, k,i,p=0;
            n = Convert.ToSingle(textBox1.Text);
            m = Convert.ToSingle(textBox2.Text);
            k = Convert.ToSingle(textBox3.Text);
            for (i = n; i <= m; i++)
            {
                if (i % k == 0)
                    p = p+1;
            }
            textBox4.Text = Convert.ToString(p);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float n, m, k, i, p = 0;
            n = Convert.ToSingle(textBox1.Text);
            m = Convert.ToSingle(textBox2.Text);
            k = Convert.ToSingle(textBox3.Text);
            for (i = n; i <= m; i++)
            {
                if (i % k == 0)
                    p = p + i;
            }
            textBox4.Text = Convert.ToString(p);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float n, m, k, i, p = 1;
            n = Convert.ToSingle(textBox1.Text);
            m = Convert.ToSingle(textBox2.Text);
            k = Convert.ToSingle(textBox3.Text);
            for (i = n; i <= m; i++)
            {
                if (i % k == 0)
                    p = p * i;
            }
            textBox4.Text = Convert.ToString(p);
        }
    }
}
