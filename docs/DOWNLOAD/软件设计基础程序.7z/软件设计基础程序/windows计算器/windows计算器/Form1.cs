﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace windows计算器
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("1");
        }

        private void butto2_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("2");
        }

        private void butto3_Click(object sender, EventArgs e)
        {
             textBox1.AppendText("3");
        }

        private void butto4_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("4");
        } 

        private void butto5_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("5");
        }

        private void butto6_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("6");
        }

        private void butto7_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("7");
        }

        private void butto8_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("8");
        }

        private void butto9_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("9");
        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("0");
        }

        private void button点_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(".");
        }

        private void button累积_Click(object sender, EventArgs e)
        {
            
            textBox1.Text = Convert.ToString((-1) * Convert.ToSingle(textBox1.Text));
        }
        float t, i;

        private void button加_Click(object sender, EventArgs e)
        {
            
            t = Convert.ToSingle(textBox1.Text);
            textBox1.Clear();
            i = 1;
           
        }

        private void button减_Click(object sender, EventArgs e)
        {
            t = Convert.ToSingle(textBox1.Text);
            textBox1.Clear();
            i = 2;
           
        }

        private void button乘_Click(object sender, EventArgs e)
        {
            t = Convert.ToSingle(textBox1.Text);
            textBox1.Clear();
            i = 3;
     
        }

        private void button除_Click(object sender, EventArgs e)
        {
            t = Convert.ToSingle(textBox1.Text);
            textBox1.Clear();
            i = 4;
          
        }
        float result;
        private void button等于_Click(object sender, EventArgs e)
        {
            float y;

            y = Convert.ToSingle(textBox1.Text);
            if (i == 1)
                result = t+y;
            if (i ==2)
                result = t-y;
            if (i ==3)
                result = y * t;
            if (i ==4)
                result = t/y;
            textBox1.Text = Convert.ToString(result);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button清空_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }
    }
}
