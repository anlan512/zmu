﻿namespace windows计算器
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.butto9 = new System.Windows.Forms.Button();
            this.butto5 = new System.Windows.Forms.Button();
            this.butto3 = new System.Windows.Forms.Button();
            this.butto4 = new System.Windows.Forms.Button();
            this.butto7 = new System.Windows.Forms.Button();
            this.butto6 = new System.Windows.Forms.Button();
            this.butto8 = new System.Windows.Forms.Button();
            this.button点 = new System.Windows.Forms.Button();
            this.button加 = new System.Windows.Forms.Button();
            this.button乘 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button除 = new System.Windows.Forms.Button();
            this.button等于 = new System.Windows.Forms.Button();
            this.butto2 = new System.Windows.Forms.Button();
            this.button减 = new System.Windows.Forms.Button();
            this.button正负切换 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button清空 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(24, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // butto9
            // 
            this.butto9.Location = new System.Drawing.Point(127, 97);
            this.butto9.Name = "butto9";
            this.butto9.Size = new System.Drawing.Size(33, 23);
            this.butto9.TabIndex = 1;
            this.butto9.Text = "9";
            this.butto9.UseVisualStyleBackColor = true;
            this.butto9.Click += new System.EventHandler(this.butto9_Click);
            // 
            // butto5
            // 
            this.butto5.Location = new System.Drawing.Point(76, 68);
            this.butto5.Name = "butto5";
            this.butto5.Size = new System.Drawing.Size(33, 23);
            this.butto5.TabIndex = 2;
            this.butto5.Text = "5";
            this.butto5.UseVisualStyleBackColor = true;
            this.butto5.Click += new System.EventHandler(this.butto5_Click);
            // 
            // butto3
            // 
            this.butto3.Location = new System.Drawing.Point(127, 39);
            this.butto3.Name = "butto3";
            this.butto3.Size = new System.Drawing.Size(33, 23);
            this.butto3.TabIndex = 3;
            this.butto3.Text = "3";
            this.butto3.UseVisualStyleBackColor = true;
            this.butto3.Click += new System.EventHandler(this.butto3_Click);
            // 
            // butto4
            // 
            this.butto4.Location = new System.Drawing.Point(24, 68);
            this.butto4.Name = "butto4";
            this.butto4.Size = new System.Drawing.Size(33, 23);
            this.butto4.TabIndex = 4;
            this.butto4.Text = "4";
            this.butto4.UseVisualStyleBackColor = true;
            this.butto4.Click += new System.EventHandler(this.butto4_Click);
            // 
            // butto7
            // 
            this.butto7.Location = new System.Drawing.Point(24, 97);
            this.butto7.Name = "butto7";
            this.butto7.Size = new System.Drawing.Size(33, 23);
            this.butto7.TabIndex = 5;
            this.butto7.Text = "7";
            this.butto7.UseVisualStyleBackColor = true;
            this.butto7.Click += new System.EventHandler(this.butto7_Click);
            // 
            // butto6
            // 
            this.butto6.Location = new System.Drawing.Point(127, 68);
            this.butto6.Name = "butto6";
            this.butto6.Size = new System.Drawing.Size(33, 23);
            this.butto6.TabIndex = 6;
            this.butto6.Text = "6";
            this.butto6.UseVisualStyleBackColor = true;
            this.butto6.Click += new System.EventHandler(this.butto6_Click);
            // 
            // butto8
            // 
            this.butto8.Location = new System.Drawing.Point(76, 97);
            this.butto8.Name = "butto8";
            this.butto8.Size = new System.Drawing.Size(33, 23);
            this.butto8.TabIndex = 7;
            this.butto8.Text = "8";
            this.butto8.UseVisualStyleBackColor = true;
            this.butto8.Click += new System.EventHandler(this.butto8_Click);
            // 
            // button点
            // 
            this.button点.Location = new System.Drawing.Point(127, 135);
            this.button点.Name = "button点";
            this.button点.Size = new System.Drawing.Size(33, 23);
            this.button点.TabIndex = 8;
            this.button点.Text = ".";
            this.button点.UseVisualStyleBackColor = true;
            this.button点.Click += new System.EventHandler(this.button点_Click);
            // 
            // button加
            // 
            this.button加.Location = new System.Drawing.Point(24, 181);
            this.button加.Name = "button加";
            this.button加.Size = new System.Drawing.Size(33, 23);
            this.button加.TabIndex = 9;
            this.button加.Text = "+";
            this.button加.UseVisualStyleBackColor = true;
            this.button加.Click += new System.EventHandler(this.button加_Click);
            // 
            // button乘
            // 
            this.button乘.Location = new System.Drawing.Point(127, 181);
            this.button乘.Name = "button乘";
            this.button乘.Size = new System.Drawing.Size(33, 23);
            this.button乘.TabIndex = 10;
            this.button乘.Text = "*";
            this.button乘.UseVisualStyleBackColor = true;
            this.button乘.Click += new System.EventHandler(this.button乘_Click);
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(76, 135);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(33, 23);
            this.button0.TabIndex = 11;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button除
            // 
            this.button除.Location = new System.Drawing.Point(24, 210);
            this.button除.Name = "button除";
            this.button除.Size = new System.Drawing.Size(33, 23);
            this.button除.TabIndex = 12;
            this.button除.Text = "/";
            this.button除.UseVisualStyleBackColor = true;
            this.button除.Click += new System.EventHandler(this.button除_Click);
            // 
            // button等于
            // 
            this.button等于.Location = new System.Drawing.Point(76, 210);
            this.button等于.Name = "button等于";
            this.button等于.Size = new System.Drawing.Size(33, 23);
            this.button等于.TabIndex = 13;
            this.button等于.Text = "=";
            this.button等于.UseVisualStyleBackColor = true;
            this.button等于.Click += new System.EventHandler(this.button等于_Click);
            // 
            // butto2
            // 
            this.butto2.Location = new System.Drawing.Point(76, 39);
            this.butto2.Name = "butto2";
            this.butto2.Size = new System.Drawing.Size(33, 23);
            this.butto2.TabIndex = 14;
            this.butto2.Text = "2";
            this.butto2.UseVisualStyleBackColor = true;
            this.butto2.Click += new System.EventHandler(this.butto2_Click);
            // 
            // button减
            // 
            this.button减.Location = new System.Drawing.Point(76, 181);
            this.button减.Name = "button减";
            this.button减.Size = new System.Drawing.Size(33, 23);
            this.button减.TabIndex = 15;
            this.button减.Text = "-";
            this.button减.UseVisualStyleBackColor = true;
            this.button减.Click += new System.EventHandler(this.button减_Click);
            // 
            // button正负切换
            // 
            this.button正负切换.Location = new System.Drawing.Point(24, 135);
            this.button正负切换.Name = "button正负切换";
            this.button正负切换.Size = new System.Drawing.Size(33, 23);
            this.button正负切换.TabIndex = 16;
            this.button正负切换.Text = "+/-";
            this.button正负切换.UseVisualStyleBackColor = true;
            this.button正负切换.Click += new System.EventHandler(this.button累积_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(9, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(162, 21);
            this.textBox1.TabIndex = 17;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button清空
            // 
            this.button清空.Location = new System.Drawing.Point(127, 210);
            this.button清空.Name = "button清空";
            this.button清空.Size = new System.Drawing.Size(33, 23);
            this.button清空.TabIndex = 18;
            this.button清空.Text = "AC";
            this.button清空.UseVisualStyleBackColor = true;
            this.button清空.Click += new System.EventHandler(this.button清空_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(188, 262);
            this.Controls.Add(this.button清空);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button正负切换);
            this.Controls.Add(this.button减);
            this.Controls.Add(this.butto2);
            this.Controls.Add(this.button等于);
            this.Controls.Add(this.button除);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button乘);
            this.Controls.Add(this.button加);
            this.Controls.Add(this.button点);
            this.Controls.Add(this.butto8);
            this.Controls.Add(this.butto6);
            this.Controls.Add(this.butto7);
            this.Controls.Add(this.butto4);
            this.Controls.Add(this.butto3);
            this.Controls.Add(this.butto5);
            this.Controls.Add(this.butto9);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button butto9;
        private System.Windows.Forms.Button butto5;
        private System.Windows.Forms.Button butto3;
        private System.Windows.Forms.Button butto4;
        private System.Windows.Forms.Button butto7;
        private System.Windows.Forms.Button butto6;
        private System.Windows.Forms.Button butto8;
        private System.Windows.Forms.Button button点;
        private System.Windows.Forms.Button button加;
        private System.Windows.Forms.Button button乘;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button除;
        private System.Windows.Forms.Button button等于;
        private System.Windows.Forms.Button butto2;
        private System.Windows.Forms.Button button减;
        private System.Windows.Forms.Button button正负切换;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button清空;
    }
}

