﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 商场收银系统
{
    class Cashfactory
    {

    }
}
