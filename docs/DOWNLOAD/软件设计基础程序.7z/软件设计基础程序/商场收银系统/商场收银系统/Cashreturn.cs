﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 商场收银系统
{
    class Cashreturn:Cashsuper
    {
        private double moneycondition = 0.0d;
        private double moneyreturn = 0.0d;
        public Cashreturn(string moneycondition, string moneyreturn)
        {
            this.moneycondition = double.Parse(moneycondition);
            this.moneyreturn = double.Parse(moneyreturn);
        }
        public override double acceptCash(double money)
        {
            double result = money;
            if (money >= moneycondition)
                result = money - Math.Floor(money / moneycondition) * moneyreturn;
            return result;
        }
    }
}
