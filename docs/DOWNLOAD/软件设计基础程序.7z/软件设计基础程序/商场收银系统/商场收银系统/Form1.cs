﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 商场收银系统
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double total = 0.0;

        private void button1_Click(object sender, EventArgs e)
        {
            double totalprise = Convert.ToDouble(textBox数量.Text) * Convert.ToDouble(textBox单价.Text);
            total = total + totalprise;
            switch (comboBox计算方式.SelectedIndex)
            {
                case 0: totalprise = totalprise * 1; break;
                case 1: totalprise = totalprise * 0.8; break;
                case 2: totalprise = totalprise * 0.7; break;
                case 3: totalprise = totalprise * 0.5; break;
            }
            lblshow.Text = Convert.ToString(total);
            listBox1.Items.Add(textBox商品名.Text + ",单价:" + textBox单价.Text + ";数量:" + textBox数量.Text + ";" + comboBox计算方式.Text + ",合计：" + totalprise.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            total = 0.0;
            textBox单价.Text =" 0.00";
            textBox数量.Text = "0";
            listBox1.Items.Clear();
            lblshow.Text = "0.00";

        }
    }
}
