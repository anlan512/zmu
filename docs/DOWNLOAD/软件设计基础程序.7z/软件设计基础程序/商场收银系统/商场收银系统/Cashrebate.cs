﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 商场收银系统
{
    class Cashrebate:Cashsuper
    {
        private double moneyrebate = 1d;
        public Cashrebate(string moneyrebate)
        {
            this.moneyrebate = double.Parse(moneyrebate);
        }
        public override double acceptCash(double money)
        {
            return money * moneyrebate;
        }
    }
}
