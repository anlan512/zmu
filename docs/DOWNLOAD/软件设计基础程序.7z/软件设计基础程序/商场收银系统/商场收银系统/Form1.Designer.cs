﻿namespace 商场收银系统
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblshow = new System.Windows.Forms.Label();
            this.button确定 = new System.Windows.Forms.Button();
            this.button重置 = new System.Windows.Forms.Button();
            this.textBox商品名 = new System.Windows.Forms.TextBox();
            this.textBox单价 = new System.Windows.Forms.TextBox();
            this.textBox数量 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox计算方式 = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "商品名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "单价";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "数量";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 241);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "总计：";
            // 
            // lblshow
            // 
            this.lblshow.AutoSize = true;
            this.lblshow.Location = new System.Drawing.Point(82, 241);
            this.lblshow.Name = "lblshow";
            this.lblshow.Size = new System.Drawing.Size(0, 12);
            this.lblshow.TabIndex = 5;
            // 
            // button确定
            // 
            this.button确定.Location = new System.Drawing.Point(180, 18);
            this.button确定.Name = "button确定";
            this.button确定.Size = new System.Drawing.Size(75, 23);
            this.button确定.TabIndex = 6;
            this.button确定.Text = "确定";
            this.button确定.UseVisualStyleBackColor = true;
            this.button确定.Click += new System.EventHandler(this.button1_Click);
            // 
            // button重置
            // 
            this.button重置.Location = new System.Drawing.Point(180, 72);
            this.button重置.Name = "button重置";
            this.button重置.Size = new System.Drawing.Size(75, 23);
            this.button重置.TabIndex = 7;
            this.button重置.Text = "重置";
            this.button重置.UseVisualStyleBackColor = true;
            this.button重置.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox商品名
            // 
            this.textBox商品名.Location = new System.Drawing.Point(96, 18);
            this.textBox商品名.Name = "textBox商品名";
            this.textBox商品名.Size = new System.Drawing.Size(67, 21);
            this.textBox商品名.TabIndex = 8;
            // 
            // textBox单价
            // 
            this.textBox单价.Location = new System.Drawing.Point(96, 50);
            this.textBox单价.Name = "textBox单价";
            this.textBox单价.Size = new System.Drawing.Size(65, 21);
            this.textBox单价.TabIndex = 9;
            // 
            // textBox数量
            // 
            this.textBox数量.Location = new System.Drawing.Point(96, 80);
            this.textBox数量.Name = "textBox数量";
            this.textBox数量.Size = new System.Drawing.Size(65, 21);
            this.textBox数量.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "计算方式";
            // 
            // comboBox计算方式
            // 
            this.comboBox计算方式.FormattingEnabled = true;
            this.comboBox计算方式.Items.AddRange(new object[] {
            "正常收费",
            "打8折",
            "打7折",
            "打5折"});
            this.comboBox计算方式.Location = new System.Drawing.Point(94, 115);
            this.comboBox计算方式.Name = "comboBox计算方式";
            this.comboBox计算方式.Size = new System.Drawing.Size(69, 20);
            this.comboBox计算方式.TabIndex = 12;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(37, 141);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(218, 88);
            this.listBox1.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.comboBox计算方式);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox数量);
            this.Controls.Add(this.textBox单价);
            this.Controls.Add(this.textBox商品名);
            this.Controls.Add(this.button重置);
            this.Controls.Add(this.button确定);
            this.Controls.Add(this.lblshow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblshow;
        private System.Windows.Forms.Button button确定;
        private System.Windows.Forms.Button button重置;
        private System.Windows.Forms.TextBox textBox商品名;
        private System.Windows.Forms.TextBox textBox单价;
        private System.Windows.Forms.TextBox textBox数量;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox计算方式;
        private System.Windows.Forms.ListBox listBox1;
    }
}

