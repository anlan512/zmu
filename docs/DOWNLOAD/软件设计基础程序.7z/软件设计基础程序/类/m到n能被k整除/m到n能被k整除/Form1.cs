﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace m到n能被k整除
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n; int k; int m; int q;
            n = Convert.ToInt32(N.Text); 
            k = Convert.ToInt32(K.Text); 
            m =Convert.ToInt32 (M.Text);
            jisuan p = new jisuan(n, m, k);
            q=p.Y();
            A.Text=Convert.ToString(q);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n; int k; int m; int q;
            n = Convert.ToInt32(N.Text); 
            k = Convert.ToInt32(K.Text); 
            m =Convert.ToInt32 (M.Text);
            jisuan p = new jisuan(n, m, k);
            q=p.Y1();
            B.Text=Convert.ToString(q);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int n; int k; int m; int q;
            n = Convert.ToInt32(N.Text); 
            k = Convert.ToInt32(K.Text); 
            m =Convert.ToInt32 (M.Text);
            jisuan p = new jisuan(n, m, k);
            q=p.Y2();
            C.Text=Convert.ToString(q);
        }
    }
}
