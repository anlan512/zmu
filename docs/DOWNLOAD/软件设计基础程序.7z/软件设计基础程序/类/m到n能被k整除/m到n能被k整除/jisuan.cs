﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace m到n能被k整除
{
    class jisuan
    {
        public int n;
        public int m;
        public int k;
        public jisuan(int n1, int m1, int k1)
        {
            n = n1;
            m = m1;
            k = k1;
        }
        public int Y()
        {
            int i = 0;
            for (int a = n; a <= m; a++)
                if (a % k == 0)
                    i++;
            return i;
        }
        public int Y1()
        {
            int i = 0;
            for (int a = n; a <= m; a++)
                if (a % k == 0)
                    i=i+a;
            return i;
        }
        public int Y2()
        {
            int i = 1;
            for (int a = n; a <= m; a++)
                if (a % k == 0)
                    i=i*a;
            return i;
        }

    }
}
