﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace a到b的累加和_控制台_
{
    class Program
    {
        static void Main(string[] args)
        {
            float a, b, p,i;
            p = 0;
            Console.WriteLine("请输入运算起始值");
            a = Convert.ToSingle(Console.ReadLine());
            Console.WriteLine("请输入运算终止值");
            b = Convert.ToSingle(Console.ReadLine());
            for ( i=a; i<= b; i++)
                p = p + i;
            Console.WriteLine("累加结果为:{0}",p);
        }
    }
}
