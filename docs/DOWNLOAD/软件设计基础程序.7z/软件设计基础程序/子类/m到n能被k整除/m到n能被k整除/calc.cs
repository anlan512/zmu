﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace m到n能被k整除
{
    class calc
    {
        public int a;
        public int b;
        public int c;
       
        }
    class calc_count : calc
        {
        public int calc_count1(int n, int m, int k)
        {
            int sum = 0;
            a = n;
            b = m;
            c = k;
            for (int i=a; a  <= b; a++)
                if (a %c == 0)
                  sum=sum+1;
            return sum;
        }
        }
    class calc_mul : calc
          {
        public int calc_mul1(int n, int m, int k)
           {
               int mul = 1;
               a = n;
               b = m;
               c = k;
               for (int i=a; a <= b; a++)
                   if (a % c == 0)
                    mul=mul*a;
            return mul;
          }
    }

            class calc_sum : calc
        {
                public int calc_sum1(int n, int m, int k)
        {
            int sum = 0;
            a = n;
            b = m;
            c = k;
            for (int i=a; a <= b; a++)
                if (a % c == 0)
                    sum=sum+a;
            return sum;
        }
        }

    }

