﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace m到n能被k整除
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n; int k; int m; 
            n = Convert.ToInt32(txtN.Text); 
            k = Convert.ToInt32(txtK.Text); 
            m =Convert.ToInt32 (txtM.Text);
            calc_count p = new calc_count();
            txtCount.Text = Convert.ToString(p.calc_count1(n,m,k));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n; int k; int m; 
            n = Convert.ToInt32(txtN.Text);
            k = Convert.ToInt32(txtK.Text);
            m = Convert.ToInt32(txtM.Text);
            calc_sum p = new calc_sum();
            txtSum.Text=Convert.ToString(p.calc_sum1(n,m,k));
        }
        private void button3_Click(object sender, EventArgs e)
        {
            int n; int k; int m; 
            n = Convert.ToInt32(txtN.Text);
            k = Convert.ToInt32(txtK.Text);
            m = Convert.ToInt32(txtM.Text);
            calc_mul p = new calc_mul();
            txtMul.Text = Convert.ToString(p.calc_mul1(n,m,k));
        }
       
    }
}
