﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 单选按钮RadioButton的使用
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
                label1.Text = "1";
            else if (radioButton2.Checked == true)
                label1.Text = "2";
            else if (radioButton3.Checked == true)
                label1.Text = "3";
            else 
                label1.Text = "4";
            
        }
    }
}
