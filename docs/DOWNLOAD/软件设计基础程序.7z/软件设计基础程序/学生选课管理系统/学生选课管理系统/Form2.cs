﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生选课管理系统
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string s = @"server=.\sqlexpress;database=zmc;integrated security=true";
            SqlConnection cn = new SqlConnection(s);
            cn.Open();
            string sql = "select*from sc";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void buttonUpdata_Click(object sender, EventArgs e)
        {
            string s = @"server=.\sqlexpress;database=zmc;integrated security=true";
            SqlConnection cn = new SqlConnection(s);
            cn.Open();
            string sql = "select*from sc";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" || textBox2.Text != "")
            {
                string s = @"server=.\sqlexpress;database=zmc;integrated security=true";
                SqlConnection cn = new SqlConnection(s);
                cn.Open();
                SqlCommand cd = new SqlCommand("insert into sc(sno,cno,grade)values('" + textBox1.Text + "','" + textBox2.Text + "','"+label3.Text+"')", cn);
                cd.ExecuteNonQuery();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s = @"server=.\sqlexpress;database=zmc;integrated security=true";
            SqlConnection cn = new SqlConnection(s);
            cn.Open();
            SqlCommand cd = new SqlCommand("delete from sc where cno='" + textBox2.Text + "'and sno='"+textBox1.Text+"'", cn);
            cd.ExecuteNonQuery();
        }
    }
}
