﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生选课管理系统
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"server=.\sqlexpress;database=zmc;integrated security=true");
            cn.Open();
            string sql = "select* from student where sno=@sno and sname=@sname";
            SqlCommand c = new SqlCommand(sql, cn);
            c.Parameters.Add("@sno", SqlDbType.VarChar);
            c.Parameters[0].Value = textBox1.Text;
            c.Parameters.Add("@sname", SqlDbType.VarChar);
            c.Parameters[1].Value = textBox2.Text;
            SqlDataReader dr = c.ExecuteReader();
  
                if(dr.Read())
                {
                  Form f = new Form2();
                    f.Show();
                }
                else
                    label3.Text = "你输入的学号或者姓名错误，登录失败";
            cn.Close();
            

           
          

        }
    }
}
