﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 交通信号灯
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
        
        }

        int t;
        private void timer1_Tick(object sender, EventArgs e)
        {
           
            t = t + 1;
            if (t > 8)
                t = 1;
            switch(t)
            {
                case 1:
                   
                case 2:
                    textBox1.BackColor = Color.Green;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White; break;
                case 3:
                   
                case 4:
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.Yellow;
                    textBox3.BackColor = Color.White; break;
                case 5:
                case 6:
                 
                case 7:
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.Red; break;
             

               
            }
                
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
           
          
                textBox4.Left = textBox4.Left + 1;
            if (textBox4.Left >= this.Width - textBox4.Width)
                textBox4.Left = 1;
            if (textBox3.BackColor == Color.Red && textBox4.Left == textBox3.Left)
                timer2.Stop();
            if (textBox3.BackColor == Color.White)
                timer2.Start();
            
         
         }

        
    }
}
