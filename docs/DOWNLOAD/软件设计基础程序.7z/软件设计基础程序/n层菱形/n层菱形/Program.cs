﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace n层菱形
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入菱形的层数（必须是奇数）");
            int i,s,x,k,n;
            n = Convert.ToInt32(Console.ReadLine());
            k=Convert.ToInt16(n/2)+1;
            for(i=1;i<=k;i++)
            {
                 for(s=k-i;s>=0;s--)
                Console.Write(" ");
            for(x=1;x<=2*i-1;x++)
                Console.Write("*");
            Console.Write("\n");
            }
            for(i=k+1;i<=n;i++)
            {
                for(s=1;s<=i-k+1;s++)
                    Console.Write(" ");
                for(x=n-(i-k)*2;x>=1;x--)
                    Console.Write("*");
                Console.Write("\n");
            }
            
        }
    }
}
